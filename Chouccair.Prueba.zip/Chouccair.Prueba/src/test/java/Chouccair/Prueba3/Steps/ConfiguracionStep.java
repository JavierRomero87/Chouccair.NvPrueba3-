package Chouccair.Prueba3.Steps;

import java.awt.AWTException;
import java.awt.Container;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.BufferedReader;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;

import org.openqa.selenium.Keys;

import Chouccair.Prueba3.RunnerFeatures;
import Chouccair.Prueba3.Model.ArchivoCSV;
import Chouccair.Prueba3.Model.TomaPantalla;
import Chouccair.Prueba3.PageObjects.ValidacionPageObjects;
import net.thucydides.core.annotations.Step;

import javax.swing.*;
import java.awt.event.*;

public class ConfiguracionStep extends JFrame implements ActionListener {

	private Container contenedor;
	JButton botonAbrir;/* declaramos el objeto Boton */
	JButton botonCerrar;/* declaramos el objeto Boton */
	JFileChooser fileChooser; /* Declaramos el objeto fileChooser */
	JLabel labelTitulo;

	public String setNombrDoc, setApellidoDoc, setApellidosDoc, setNumeroDoc, setFechaErrada, setFecha;

	ValidacionPageObjects page;

	@Step
	public void CapturaPantalla() throws AWTException, IOException {

		TomaPantalla captura = new TomaPantalla();
		page.open();
		page.PasoNueve();
		captura.CapturaPuento();

	}

	@Step
	public void IngresoDatos() throws IOException {
		
		Carge();
		page.IngresarInformacon(setNombrDoc, setApellidoDoc, setApellidosDoc, setNumeroDoc, setFechaErrada, setFecha);
	}

	public void RegistroExitoso() {

	}

	public ConfiguracionStep() {
		contenedor = getContentPane();
		contenedor.setLayout(null);

		fileChooser = new JFileChooser();

		labelTitulo = new JLabel();
		labelTitulo.setText("Cargar Archivo");
		labelTitulo.setBounds(5, 10, 100, 23);

		botonAbrir = new JButton();
		botonAbrir.setText("Abrir");
		botonAbrir.setBounds(5, 100, 80, 23);
		botonAbrir.addActionListener(this);

		botonCerrar = new JButton();
		botonCerrar.setText("Cerrar");
		botonCerrar.setBounds(110, 100, 80, 23);
		botonCerrar.addActionListener(this);

		contenedor.add(labelTitulo);
		contenedor.add(botonAbrir);
		contenedor.add(botonCerrar);
		setSize(210, 200);
		setLocationRelativeTo(null);

	}

	@Override
	public void actionPerformed(ActionEvent evento) {

		if (evento.getSource() == botonAbrir) {
			abrirArchivo();
		}

		if (evento.getSource() == botonCerrar) {

			cerrarArchivo();

		}
	}

	private String[] abrirArchivo() {

		String aux = "";
		String[] texto = null;
		String cvsSplitBy = ",";

		String setNombrDoc = null;
		String setApellidoDoc;
		String setApellidosDoc;
		String setNumeroDoc;
		String setFechaErrada;
		String setFecha;

		try {

			fileChooser.showOpenDialog(this);
			File abre = fileChooser.getSelectedFile();
			if (abre != null) {

				FileReader archivos = new FileReader(abre);
				BufferedReader lee = new BufferedReader(archivos);
				while ((aux = lee.readLine()) != null) {

					texto = aux.split(cvsSplitBy);

					for (int i = 0; i < texto.length; i++) {
						setNombrDoc = (texto[0]);
						setApellidoDoc = (texto[1]);
						setApellidosDoc = (texto[2]);
						setNumeroDoc = (texto[3]);
						setFechaErrada = (texto[4]);
						setFecha = (texto[5]);

					}
					
				}

				lee.close();
				System.exit(0);
			}
		} catch (IOException ex) {
			JOptionPane.showMessageDialog(null, ex + "" + "\nNo se ha encontrado el archivo", "ADVERTENCIA!!!",
					JOptionPane.WARNING_MESSAGE);
		}
		return texto;
	}

	private void cerrarArchivo() {

		System.exit(0);

	}
	
	public void Carge() {
		ConfiguracionStep miVentana = new ConfiguracionStep();
		miVentana.setVisible(true);
	}

}
