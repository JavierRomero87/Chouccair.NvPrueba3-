package Chouccair.Prueba3.Model;

import java.awt.AWTException;
import java.awt.Dimension;
import java.awt.Rectangle;
import java.awt.Robot;
import java.awt.Toolkit;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;

import javax.imageio.ImageIO;

public class TomaPantalla {
	
	public void CapturaPuento() throws AWTException, IOException {
	
	String fileName = "C:\\Users\\gromerom\\Desktop\\archivo.png" ;
	
	Dimension screenSize = Toolkit.getDefaultToolkit().getScreenSize();
	Rectangle screenRectangle = new Rectangle(screenSize);
	Robot robot = new Robot();
	BufferedImage image = robot.createScreenCapture(screenRectangle);
	ImageIO.write(image, "png", new File(fileName));
	
	}
}
